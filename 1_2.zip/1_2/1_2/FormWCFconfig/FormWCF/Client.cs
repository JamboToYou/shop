﻿namespace FormWCF
{
    internal class Client
    {
        internal int idClient;
    }
}